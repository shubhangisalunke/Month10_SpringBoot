package com.citi.training.controller;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/first")
public class FirstController {
	
	@RequestMapping(path="/msg",produces = MediaType.TEXT_HTML_VALUE,method = RequestMethod.GET)
	@ResponseBody public String getMessage() {
		return "<html><body><h2>------Welcome to Spring Boot -----</h2></body></html>";
	}
	
	@RequestMapping(path="/msg/{fName}/{lName}",produces = MediaType.TEXT_HTML_VALUE,method = RequestMethod.GET)
	@ResponseBody public String getAnotherMessage(@PathVariable("fName")String firstName,
			@PathVariable("lName")String  lastName){
		return "<html><body><h2>------Welcome to Spring Boot -----"+firstName+" "+lastName+"</h2></body></html>";
	}

}
