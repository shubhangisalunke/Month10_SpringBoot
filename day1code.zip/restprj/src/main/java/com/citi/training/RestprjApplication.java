package com.citi.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestprjApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestprjApplication.class, args);
	}

}
