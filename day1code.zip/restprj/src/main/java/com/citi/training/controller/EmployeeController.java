package com.citi.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.training.domain.Employee;
import com.citi.training.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@RequestMapping(path="/{empId}",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable("empId")int id)
	//if the client sends the value for /{empId} as /1001, the parameter id will be replaced with 1001.
	{
		return new ResponseEntity<Employee>(service.getEmployee(id), HttpStatus.OK);
	}
	
	@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
	public ResponseEntity<List<Employee>> getAllEmployees()
	//if the client sends the value for /{empId} as /1001, the parameter id will be replaced with 1001.
	{
		return new ResponseEntity<>(service.getAllEmployees(),HttpStatus.OK);
	}
	
	@RequestMapping(consumes = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.POST,
			produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> addEmployee(@RequestBody Employee e)
	//if the client sends the value for /{empId} as /1001, the parameter id will be replaced with 1001.
	{
		String msg=service.addEmployee(e);
		//HttpStatus.CREATED----------201
		return new ResponseEntity<>("<html><body>"+msg+"</body></html>",HttpStatus.CREATED);
	}

	@RequestMapping(path="/{id}",consumes = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.PUT,
			produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> updateEmployee(@PathVariable("id") int empId,
			@RequestBody Employee e)
	//if the client sends the value for /{empId} as /1001, the parameter id will be replaced with 1001.
	{
		String msg=service.updateEmployee(empId, e);
		
		return new ResponseEntity<>("<html><body>"+msg+"</body></html>",HttpStatus.OK);
	}
	@RequestMapping(path="/{id}",method = RequestMethod.DELETE,
			produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> removeEmployee(@PathVariable("id") int empId)
	//if the client sends the value for /{empId} as /1001, the parameter id will be replaced with 1001.
	{
		String msg=service.removeEmployee(empId);
		
		return new ResponseEntity<>("<html><body>"+msg+"</body></html>",HttpStatus.OK);
	}
}
