package com.citi.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.citi.training.domain.Employee;

@Service
public class EmployeeService {
	private TreeMap<Integer, Employee> empData=new TreeMap<>();
	
	public EmployeeService()
	{
		empData.put(1001, new Employee(1001, "Arvind", "Developer"));
		empData.put(1002, new Employee(1002, "Amar", "Accountant"));
		empData.put(1003, new Employee(1003, "Rajiv", "Architect"));
	}
	
	public Employee getEmployee(int id) {
		return empData.get(id);
	}
	
	public List<Employee> getAllEmployees()
	{
		return new ArrayList<>(empData.values());
	}
	
	public String addEmployee(Employee e)
	{
		int nextId=empData.lastKey()+1;
		e.setId(nextId);
		empData.put(nextId, e);
		return "employee with id "+nextId+" added successfully";
	}
	
	public String updateEmployee(int id,Employee e)
	{
		Employee e1=empData.get(id);
		if(e.getName()!=null) {
			e1.setName(e.getName());
		}
		e1.setDesignation(e.getDesignation());
		return "employee with id "+id+" updated successfully";
	}
	
	public String removeEmployee(int id)
	{
		empData.remove(id);
		return "employee with id "+id+" removed successfully";
	}
	
	
}
